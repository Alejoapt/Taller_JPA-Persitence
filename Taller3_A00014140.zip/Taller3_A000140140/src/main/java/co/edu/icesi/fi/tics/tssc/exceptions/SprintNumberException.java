package co.edu.icesi.fi.tics.tssc.exceptions;

public class SprintNumberException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SprintNumberException() {
		super("The minimun number of sprints must be greater than 0");
	}
	

}
