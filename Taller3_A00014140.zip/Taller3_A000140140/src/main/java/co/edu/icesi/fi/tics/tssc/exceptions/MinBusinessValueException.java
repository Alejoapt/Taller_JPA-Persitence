package co.edu.icesi.fi.tics.tssc.exceptions;

public class MinBusinessValueException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MinBusinessValueException() {
		super("The minimun value of business must be greater than 0");
	}
}
