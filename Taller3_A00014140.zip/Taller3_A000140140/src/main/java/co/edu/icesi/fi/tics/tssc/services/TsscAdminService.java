package co.edu.icesi.fi.tics.tssc.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.edu.icesi.fi.tics.tssc.exceptions.AdminNotExistException;
import co.edu.icesi.fi.tics.tssc.exceptions.AdminNotNullException;
import co.edu.icesi.fi.tics.tssc.model.TsscAdmin;
import co.edu.icesi.fi.tics.tssc.repositories.ITsscAdminRepository;

@Service
public class TsscAdminService implements ITsscAdminService{
	
	@Autowired
	private ITsscAdminRepository adminRepository;

	@Override
	public TsscAdmin addAdmin(TsscAdmin admin) throws AdminNotNullException {
		if(admin!= null)
		{
			adminRepository.save(admin);
			return admin;
		}else throw new AdminNotNullException();
	}



	@Override
	public TsscAdmin editAdmin(TsscAdmin admin) throws AdminNotNullException, AdminNotExistException {
		if(admin!= null)
		{
			if(adminRepository.findById(admin.getId())!= null)
			{
				adminRepository.save(admin);
				return admin;
			}else throw new AdminNotExistException();
		}else throw new AdminNotNullException();

	}

}
