package co.edu.icesi.fi.tics.tssc.dao;

import java.util.List;

import co.edu.icesi.fi.tics.tssc.model.TsscStory;

public interface ITsscStoryDao {

	public void add(TsscStory entity);

	public void update(TsscStory enity);

	public void delete(TsscStory entity);

	public List<TsscStory> findAll();

	public TsscStory findStoryById(long id);

	public List<TsscStory> findStoryByGame(long idGame);

}
