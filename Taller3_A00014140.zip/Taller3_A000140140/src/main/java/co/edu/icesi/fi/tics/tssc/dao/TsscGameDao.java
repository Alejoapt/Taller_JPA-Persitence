package co.edu.icesi.fi.tics.tssc.dao;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import co.edu.icesi.fi.tics.tssc.model.TsscGame;

@Repository
@Scope("singleton")
public class TsscGameDao implements ITsscGameDao {

	@PersistenceContext
	private EntityManager entityManager;

	// PN°1b

	@SuppressWarnings("unchecked")
	@Override
	public List<TsscGame> findByName(String name) {
		String sql = "SELECT a FROM TsscGame a WHERE a.name = '" + name + "'";
		return entityManager.createQuery(sql).getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TsscGame> findByDescription(String description) {
		String sql = "SELECT a FROM TsscGame a WHERE a.description = '" + description + "'";
		return entityManager.createQuery(sql).getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TsscGame> findByTopicId(long idTopic) {
		String sql = "SELECT a FROM TsscGame a WHERE a.topic.id = :idTopic";
		Query query = entityManager.createQuery(sql);
		query.setParameter("idTopic", idTopic);
		return entityManager.createQuery(sql).getResultList();
	}

	// --------------------------------------------------------

	// PN°1 c
	@SuppressWarnings("unchecked")
	@Override
	public List<TsscGame> findGameByDateRange(LocalDate aDate, LocalDate bDate) {
		String sql = "SELECT a FROM TsscGame a WHERE a.scheduledDate <= :bDate AND a.scheduledDate >= :aDate";
		Query query = entityManager.createQuery(sql);
		query.setParameter("aDate", aDate);
		query.setParameter("bDate", bDate);
		List<TsscGame> results = query.getResultList();
		return results;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TsscGame> findGameByDateAndHourRange(LocalDate date, LocalTime aTime, LocalTime bTime) {
		String sql = "SELECT a FROM TsscGame a WHERE a.scheduledDate = :date"
				+ " AND a.scheduledTime >= :aTime AND a.scheduledTime <= :bTime";
		Query query = entityManager.createQuery(sql);
		query.setParameter("date", date);
		query.setParameter("aTime", aTime);
		query.setParameter("bTime", bTime);
		List<TsscGame> results = query.getResultList();
		return results;
	}

	// ----------------------------------------------------

	// PN°2 a

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> findTopicsByDate(LocalDate date) {

		String j1 = "SELECT a,b FROM TsscTopic a RIGHT JOIN TsscGame b ON a = b.tsscTopic"
				+ " WHERE b.scheduledDate = :date GROUP BY(a.name), b.scheduledTime ORDER BY b.scheduledTime";
		Query query = entityManager.createQuery(j1);
		query.setParameter("date", date);
		List<Object[]> results = query.getResultList();

		return results;
	}

	// ----------------------------------------------------

	// PN°2 b

	@SuppressWarnings("unchecked")
	@Override
	public List<TsscGame> findGameByTime(LocalDate date) {
		String jpql = "SELECT a FROM TsscGame a WHERE a.scheduledDate = :date AND (size(a.tsscStories)<10 "
				+ "OR size(a.tsscTimecontrols) = 0)";
		Query query = entityManager.createQuery(jpql);
		query.setParameter("date", date);
		List<TsscGame> results = query.getResultList();
		return results;
	}

	// ----------------------------------------------------

	@Override
	public void add(TsscGame entity) {
		entityManager.persist(entity);
	}

	@Override
	public void update(TsscGame entity) {
		entityManager.merge(entity);
	}

	@Override
	public void delete(TsscGame entity) {
		entityManager.remove(entity);
	}

	@Override
	public TsscGame findGameById(long id) {
		return entityManager.find(TsscGame.class, id);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TsscGame> findAll() {
		String sql = "SELECT a FROM TsscGame a";
		return entityManager.createQuery(sql).getResultList();
	}

}
