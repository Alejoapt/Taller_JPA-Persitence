package co.edu.icesi.fi.tics.tssc.exceptions;

public class StoryNotExistException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public StoryNotExistException() {
		super("The story must exist");
	}
}
