package co.edu.icesi.fi.tics.tssc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import co.edu.icesi.fi.tics.tssc.services.TsscAdminService;

@Controller
public class AdminController {

	
	TsscAdminService adminService;
	
	@Autowired
	public AdminController(TsscAdminService adminService)
	{
		this.adminService = adminService;
	}
	
	/*
	 * Log in mapping
	 */
	@GetMapping("/login")
	public String login() {
		return "/loginAdmin";
	}
	
}
