package co.edu.icesi.fi.tics.tssc.repositories;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import co.edu.icesi.fi.tics.tssc.model.TsscTimecontrol;

@Repository
public class TsscTimecontrolRepository implements ITsscTimecontrolRepository {

	private Map<Long, TsscTimecontrol> timecontrolMap;	

	public  TsscTimecontrolRepository() {
		timecontrolMap = new HashMap<Long, TsscTimecontrol>();

	}
	@Override
	public void addTimecontrol(TsscTimecontrol timecontrol) {
		timecontrolMap.put(timecontrol.getId(),timecontrol);
	}

	@Override
	public void editTimeControl(TsscTimecontrol timecontrol) {
		TsscTimecontrol existingtimecontrol = timecontrolMap.get(timecontrol.getId());
		timecontrolMap.replace(timecontrol.getId(), timecontrol, existingtimecontrol);		
	}

}
