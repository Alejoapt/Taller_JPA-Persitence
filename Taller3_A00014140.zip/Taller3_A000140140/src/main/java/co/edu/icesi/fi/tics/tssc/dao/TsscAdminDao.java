package co.edu.icesi.fi.tics.tssc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;
import co.edu.icesi.fi.tics.tssc.model.TsscAdmin;

@Repository
@Scope("singleton")
public class TsscAdminDao implements ITsscAdminDao{
	
	@PersistenceContext
	private EntityManager entityManager;
	
	
	@Override
	public void add(TsscAdmin entity) {
		entityManager.persist(entity);
	}

	@Override
	public void update(TsscAdmin enity) {
		entityManager.merge(enity);
	}

	@Override
	public void delete(TsscAdmin entity) {
		entityManager.remove(entity);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TsscAdmin> findAll() {
		String sql = "SELECT a FROM TsscAdmin a";
		return entityManager.createQuery(sql).getResultList();
	}

	@Override
	public TsscAdmin findAdminById(long id) {
		return entityManager.find(TsscAdmin.class, id);
	}

}
