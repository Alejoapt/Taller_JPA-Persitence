package co.edu.icesi.fi.tics.tssc.services;

import java.util.Optional;


import co.edu.icesi.fi.tics.tssc.exceptions.GroupNumberException;
import co.edu.icesi.fi.tics.tssc.exceptions.SprintNumberException;
import co.edu.icesi.fi.tics.tssc.exceptions.GameNotExistException;
import co.edu.icesi.fi.tics.tssc.exceptions.TopicNotExistException;
import co.edu.icesi.fi.tics.tssc.exceptions.GameNotNullException;
import co.edu.icesi.fi.tics.tssc.model.TsscGame;
import co.edu.icesi.fi.tics.tssc.model.TsscTopic;

public interface ITsscGameService {

	public TsscGame addGame(TsscGame game, TsscTopic topic) throws GameNotNullException, SprintNumberException,
			GameNotNullException, GroupNumberException, TopicNotExistException;

	public TsscGame editGame(TsscGame game) throws GameNotExistException, GameNotNullException, GroupNumberException,
			SprintNumberException, TopicNotExistException;

	public void deleteGame(TsscGame game);

	public Iterable<TsscGame> findAll();

	public Optional<TsscGame> findGameById(long id);

	public Iterable<TsscGame> findByIdTopic(long idTopic);

}
