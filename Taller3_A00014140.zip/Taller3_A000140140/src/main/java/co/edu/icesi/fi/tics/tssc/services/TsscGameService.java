package co.edu.icesi.fi.tics.tssc.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import co.edu.icesi.fi.tics.tssc.exceptions.GroupNumberException;
import co.edu.icesi.fi.tics.tssc.exceptions.SprintNumberException;
import co.edu.icesi.fi.tics.tssc.exceptions.GameNotExistException;
import co.edu.icesi.fi.tics.tssc.exceptions.TopicNotExistException;
import co.edu.icesi.fi.tics.tssc.exceptions.GameNotNullException;
import co.edu.icesi.fi.tics.tssc.model.TsscGame;
import co.edu.icesi.fi.tics.tssc.model.TsscTopic;
import co.edu.icesi.fi.tics.tssc.repositories.ITsscGameRepository;
import co.edu.icesi.fi.tics.tssc.repositories.ITsscTopicRepository;

@Service
public class TsscGameService implements ITsscGameService {

	@Autowired
	private ITsscGameRepository gameRepository;

	@Autowired
	private ITsscTopicRepository topicRepository;

	@Override
	public TsscGame addGame(TsscGame game, TsscTopic topic)
			throws GroupNumberException, SprintNumberException, GameNotNullException, TopicNotExistException {
		if (game != null) {
			if (game.getNGroups() > 0) {
				if (game.getNSprints() > 0) {
					if (topic == null) {
						gameRepository.save(game);
						return game;
					} else {
						if (topicRepository.existsById(topic.getId())) {
							game.setTsscTopic(topic);
							game.setIdTopic(game.getTsscTopic().getId());

							gameRepository.save(game);
							return game;
						} else
							throw new TopicNotExistException();
					}
				} else
					throw new SprintNumberException();
			} else
				throw new GroupNumberException();
		} else
			throw new GameNotNullException();
	}

	@Override
	public TsscGame editGame(TsscGame game) throws GameNotExistException, GameNotNullException, GroupNumberException,
			SprintNumberException, TopicNotExistException {

		if (game != null) {
			if (gameRepository.existsById(game.getId())) {

				if (game.getNGroups() > 0) {
					if (game.getNSprints() > 0) {
						if (game.getTsscTopic() != null) {
							if (topicRepository.existsById(game.getTsscTopic().getId())) {
								game.setIdTopic(game.getTsscTopic().getId());
								gameRepository.save(game);
								return game;
							} else
								throw new TopicNotExistException();
						} else {
							gameRepository.save(game);
							return game;
						}
					} else
						throw new SprintNumberException();
				} else
					throw new GroupNumberException();

			} else
				throw new GameNotExistException();

		} else
			throw new GameNotNullException();

	}

	@Override
	public void deleteGame(TsscGame game) {
		gameRepository.delete(game);
	}


	public Iterable<TsscGame> findAll() {
		return gameRepository.findAll();
	}

	@Override
	public Optional<TsscGame> findGameById(long id) {

		return gameRepository.findById(id);
	}

	@Override
	public Iterable<TsscGame> findByIdTopic(long idTopic) {
		return gameRepository.findByIdTopic(idTopic);
	}

}
