package co.edu.icesi.fi.tics.tssc.model;

public interface ITsscTopicValidation {

}
