package co.edu.icesi.fi.tics.tssc.exceptions;

public class StoryNotNullException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public StoryNotNullException()
	{
		super("The story must be different than null");
	}
	
	

}
