package co.edu.icesi.fi.tics.tssc.services;

import co.edu.icesi.fi.tics.tssc.exceptions.AdminNotExistException;
import co.edu.icesi.fi.tics.tssc.exceptions.AdminNotNullException;
import co.edu.icesi.fi.tics.tssc.model.TsscAdmin;

public interface ITsscAdminService {

	public TsscAdmin addAdmin(TsscAdmin admin) throws AdminNotNullException;

	public TsscAdmin editAdmin(TsscAdmin admin) throws AdminNotNullException, AdminNotExistException;
}
