package co.edu.icesi.fi.tics.tssc.repositories;

import java.util.HashMap;
import java.util.Map;

import co.edu.icesi.fi.tics.tssc.model.TsscGroup;

public class TsscGroupRespository implements ITsscGroupRespository{
	
	private Map<Long, TsscGroup> groupMap;

	
	public  TsscGroupRespository(TsscGroup tsscGroup) {
		groupMap = new HashMap<Long, TsscGroup>();
	}
	
	@Override
	public void addGroup(TsscGroup tsscGroup) {
		groupMap.put(tsscGroup.getId(), tsscGroup);
	}

	@Override
	public TsscGroup getGroup(long id) {
		return groupMap.get(id);
	}

	@Override
	public TsscGroup editGroup(TsscGroup tsscGroup) {
		TsscGroup existingGame = groupMap.get(tsscGroup.getId());
		groupMap.replace(tsscGroup.getId(), tsscGroup, existingGame);
		return tsscGroup;
	}

}
