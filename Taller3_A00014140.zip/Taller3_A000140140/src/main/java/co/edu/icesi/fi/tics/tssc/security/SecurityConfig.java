package co.edu.icesi.fi.tics.tssc.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	private LoggingAccessDeniedHandler accessDeniedHandler;

	@Override
	protected void configure(HttpSecurity httpSecurity) throws Exception {

		httpSecurity.authorizeRequests().antMatchers("/index/**").hasAnyRole("superAdmin", "admin", "user")

				.antMatchers("/tsscGames/").hasAnyRole("superAdmin", "admin", "user").antMatchers("/tsscGames/addTsscGame")
				.hasAnyRole("superAdmin", "admin")

				.antMatchers("/tsscStories/").hasAnyRole("superAdmin", "admin", "user").antMatchers("/tsscStories/addTsscStory")
				.hasAnyRole("admin", "super")

				.antMatchers("/tsscTopics/**").hasRole("superAdmin")

				.anyRequest().authenticated().and().formLogin().loginPage("/login").permitAll().and().logout()
				.invalidateHttpSession(true).clearAuthentication(true)
				.logoutRequestMatcher(new AntPathRequestMatcher("/logout")).logoutSuccessUrl("/login?logout")
				.permitAll().and().exceptionHandling().accessDeniedHandler(accessDeniedHandler);

	}

}