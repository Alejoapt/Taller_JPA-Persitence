package co.edu.icesi.fi.tics.tssc.dao;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import co.edu.icesi.fi.tics.tssc.model.TsscGame;

public interface ITsscGameDao {

	// PN°1b
	public List<TsscGame> findByName(String name);

	public List<TsscGame> findByDescription(String description);

	public List<TsscGame> findByTopicId(long idTopic);

	// ---------------------------------------------------

	// PN1°c

	public List<TsscGame> findGameByDateRange(LocalDate aDate, LocalDate bDate);

	public List<TsscGame> findGameByDateAndHourRange(LocalDate date, LocalTime aTime, LocalTime bTime);

	// ----------------------------------------------------

	// PN°2 a

	public List<Object[]> findTopicsByDate(LocalDate date);

	// ----------------------------------------------------

	// PN°2 b

	public List<TsscGame> findGameByTime(LocalDate date);

	// ----------------------------------------------------

	public void add(TsscGame entity);

	public void update(TsscGame entity);

	public void delete(TsscGame entity);

	public TsscGame findGameById(long id);

	public List<TsscGame> findAll();

}
