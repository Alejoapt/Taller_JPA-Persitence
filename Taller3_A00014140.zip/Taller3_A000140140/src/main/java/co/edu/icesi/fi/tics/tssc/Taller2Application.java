package co.edu.icesi.fi.tics.tssc;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.thymeleaf.extras.java8time.dialect.Java8TimeDialect;
import co.edu.icesi.fi.tics.tssc.exceptions.MinBusinessValueException;
import co.edu.icesi.fi.tics.tssc.exceptions.InitialSprintException;
import co.edu.icesi.fi.tics.tssc.exceptions.GroupNumberException;
import co.edu.icesi.fi.tics.tssc.exceptions.SprintNumberException;
import co.edu.icesi.fi.tics.tssc.exceptions.GameNotExistException;
import co.edu.icesi.fi.tics.tssc.exceptions.TopicNotExistException;
import co.edu.icesi.fi.tics.tssc.exceptions.AdminNotNullException;
import co.edu.icesi.fi.tics.tssc.exceptions.GameNotNullException;
import co.edu.icesi.fi.tics.tssc.exceptions.StoryNotNullException;
import co.edu.icesi.fi.tics.tssc.exceptions.TopicNotNullException;
import co.edu.icesi.fi.tics.tssc.exceptions.MinPriorityException;
import co.edu.icesi.fi.tics.tssc.model.TsscAdmin;
import co.edu.icesi.fi.tics.tssc.model.TsscGame;
import co.edu.icesi.fi.tics.tssc.model.TsscStory;
import co.edu.icesi.fi.tics.tssc.model.TsscTopic;
import co.edu.icesi.fi.tics.tssc.services.TsscAdminService;
import co.edu.icesi.fi.tics.tssc.services.TsscGameService;
import co.edu.icesi.fi.tics.tssc.services.TsscStoryService;
import co.edu.icesi.fi.tics.tssc.services.TsscTopicService;

@SpringBootApplication
public class Taller2Application {

	@Bean
	public Java8TimeDialect java8TimeDialect() {
		return new Java8TimeDialect();
	}

	public static void main(String[] args)
			throws InitialSprintException,MinBusinessValueException, GroupNumberException, SprintNumberException, TopicNotExistException,
			 AdminNotNullException, GameNotNullException, StoryNotNullException,
			TopicNotNullException, MinPriorityException, GameNotExistException {

		ConfigurableApplicationContext c = SpringApplication.run(Taller2Application.class, args);
		TsscGameService gameService = c.getBean(TsscGameService.class);
		TsscAdminService adminService = c.getBean(TsscAdminService.class);
		TsscTopicService topicService = c.getBean(TsscTopicService.class);
		TsscStoryService storyService = c.getBean(TsscStoryService.class);

		TsscAdmin admin1 = new TsscAdmin();
		admin1.setPassword("{noop}123");
		admin1.setUsername("Super Admin");
		admin1.setUser("Super Admin");
		admin1.setSuperAdmin("superAdmin");

		adminService.addAdmin(admin1);

		TsscAdmin admin2 = new TsscAdmin();
		admin2.setPassword("{noop}123");
		admin2.setUsername("Admin");
		admin2.setUser("Admin");
		admin2.setSuperAdmin("admin");

		adminService.addAdmin(admin2);
		TsscAdmin user = new TsscAdmin();
		user.setPassword("{noop}123");
		user.setUsername("User");
		user.setUser("User");
		user.setSuperAdmin("user");
		adminService.addAdmin(user);

		TsscTopic topic = new TsscTopic();
		topic.setDefaultGroups(3);
		topic.setDefaultSprints(3);
		topic.setGroupPrefix("AMB");
		topic.setName("Arena Multiplayer");
		topic.setDescription("Multiplayer arena battle");
		topicService.saveTopic(topic);

		TsscTopic topic2 = new TsscTopic();
		topic2.setDefaultGroups(4);
		topic2.setDefaultSprints(5);
		topic2.setName("Shooter");
		topic2.setGroupPrefix("SB");
		topic2.setDescription("Shooter battle");
		topicService.saveTopic(topic2);

		TsscGame game = new TsscGame();
		game.setName("League Of Legends");
		game.setNGroups(4);
		game.setNSprints(3);
		Date date = new Date();
		game.setScheduledDate(convertToLocalDateViaInstant(date));
		gameService.addGame(game, topic);
		TsscGame game2 = new TsscGame();
		game2.setName("Call of duty");
		game2.setNGroups(10);
		game2.setNSprints(3);
		Date date2 = new Date();
		game2.setScheduledDate(convertToLocalDateViaInstant(date2));
		gameService.addGame(game2, topic);

		TsscStory story = new TsscStory();
		story.setDescription("Story 1");
		story.setBusinessValue(new BigDecimal("10000"));
		story.setPriority(new BigDecimal("1"));
		story.setInitialSprint(new BigDecimal("4"));
		storyService.addStory(story, game);

		TsscStory story2 = new TsscStory();
		story2.setDescription("Story 2");
		story2.setBusinessValue(new BigDecimal("10000"));
		story2.setPriority(new BigDecimal("70"));
		story2.setInitialSprint(new BigDecimal("4"));

		storyService.addStory(story2, game);

	}

	public static LocalDate convertToLocalDateViaInstant(Date dateToConvert) {
		return dateToConvert.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
	}

}
