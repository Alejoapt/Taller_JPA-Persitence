package co.edu.icesi.fi.tics.tssc.repositories;

import co.edu.icesi.fi.tics.tssc.model.TsscGroup;

public interface ITsscGroupRespository {
	
	public void addGroup(TsscGroup tsscGroup); 
	public TsscGroup editGroup(TsscGroup tsscGroup);
	public TsscGroup getGroup(long id);

}
