package co.edu.icesi.fi.tics.tssc.repositories;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import co.edu.icesi.fi.tics.tssc.model.TsscSprint;

@Repository
public class TsscSprintRepository implements ITsscSprintRepository {

	private Map<Long, TsscSprint> sprintMap;	

	public TsscSprintRepository()
	{
		sprintMap = new HashMap<Long, TsscSprint>();
	}
	
	@Override
	public void addSprint(TsscSprint sprint) {
		sprintMap.put(sprint.getId(), sprint);
		
	}

	@Override
	public void editSprint(TsscSprint sprint) {

		TsscSprint existingSprint = sprintMap.get(sprint.getId());
		sprintMap.replace(sprint.getId(), sprint, existingSprint);
		
	}

}
