package co.edu.icesi.fi.tics.tssc.controller;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import co.edu.icesi.fi.tics.tssc.exceptions.GroupNumberException;
import co.edu.icesi.fi.tics.tssc.exceptions.SprintNumberException;
import co.edu.icesi.fi.tics.tssc.exceptions.TopicNotExistException;
import co.edu.icesi.fi.tics.tssc.exceptions.TopicNotNullException;
import co.edu.icesi.fi.tics.tssc.model.ITsscTopicValidation;
import co.edu.icesi.fi.tics.tssc.model.TsscTopic;
import co.edu.icesi.fi.tics.tssc.services.TsscTopicService;

@Controller
public class TopicController {

	private TsscTopicService topicService;

	@Autowired
	public TopicController(TsscTopicService topicService) {
		this.topicService = topicService;
	}
	
	/**
	 * Principal index tsscTopic
	 * @param model
	 * @return
	 */

	@GetMapping("/tsscTopics/")
	public String indexTopic(Model model) {
		System.out.println(topicService.findAll());
		model.addAttribute("topics", topicService.findAll());

		return "tsscTopics/index";
	}

	/*
	 * Add mapping for tsscTopic 
	 */
	
	@GetMapping("tsscTopics/add")
	public String addTsscTopic(Model model) {
		model.addAttribute("topic", new TsscTopic());
		return "tsscTopics/addTsscTopic";
	}
	
	/*
	 * Add post mapping for tsscTopic
	 */

	@PostMapping("tsscTopics/add")
	public String addTsscTopic(@RequestParam(value = "action", required = true) String action,
			@Validated(ITsscTopicValidation.class) @ModelAttribute("topic") TsscTopic topic, BindingResult bindingResult,
			Model model) throws TopicNotNullException, GroupNumberException, SprintNumberException {
		if (!action.equals("Cancel")) {
			if (bindingResult.hasErrors()) {
				return "tsscTopics/addTsscTopic";
			} else {
				topicService.saveTopic(topic);
			}
		} else {
			return "tsscTopics/index";
		}
		return "redirect:/tsscTopics/";
	}


	/*
	 * Get topics by id
	 */
	@GetMapping("/tsscTopics/getTopics/{id}")
	public String getTsscTopics(@PathVariable("id") long id, Model model) {
		Optional<TsscTopic> topic = topicService.findTopicById(id);
		if (topic != null) {
			model.addAttribute("topics", topic.get());
		}
		return "tsscTopics/indexTopicsGame";

	}
	
	@GetMapping("/tsscTopics/edit/{id}")
	public String editTsscTopic(@PathVariable("id") long id, Model model) {
		Optional<TsscTopic> topic = topicService.findTopicById(id);
		if (topic == null)
			throw new IllegalArgumentException("Invalid Topic Id:" + id);
		model.addAttribute("topic", topic.get());
		model.addAttribute("mode", "edit1");
		return "tsscTopics/editTsscTopic";
	}


	@PostMapping("/tsscTopics/edit/{id}")
	public String editTsscTopic(@PathVariable("id") long id, @RequestParam(value = "action", required = false) String action,
			@Validated(ITsscTopicValidation.class) @ModelAttribute("topic") TsscTopic topic, BindingResult bindingResult,
			Model model)
			throws TopicNotNullException, TopicNotExistException, SprintNumberException, GroupNumberException {
		if (action != null && !action.equals("Cancel")) {
			if (bindingResult.hasErrors()) {
				return "/tsscTopics/editTsscTopic";
			} else {
				topicService.editTopic(topic);
			}
		}
		if (action.equals("Update Topic")) {
			return "redirect:/tsscTopics/";
		} else {
			return "redirect:/tsscGames/";

		}
	}

	@GetMapping("/tsscTopics/del/{id}")
	public String deleteTsscTopic(@PathVariable("id") long id) {
		TsscTopic topic = topicService.findTopicById(id)
				.orElseThrow(() -> new IllegalArgumentException("Invalidad Topic id: " + id));
		topicService.deleteTopic(topic);
		return "redirect:/tsscTopics/";
	}

}
