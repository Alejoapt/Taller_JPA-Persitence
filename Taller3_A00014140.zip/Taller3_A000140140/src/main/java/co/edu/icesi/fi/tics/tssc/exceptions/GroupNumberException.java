package co.edu.icesi.fi.tics.tssc.exceptions;

public class GroupNumberException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GroupNumberException() {
		super("The minimun number of groups must be greater than 0");
	}
}
