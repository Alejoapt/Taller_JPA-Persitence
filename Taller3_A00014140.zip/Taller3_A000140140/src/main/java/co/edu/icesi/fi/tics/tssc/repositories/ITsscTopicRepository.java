package co.edu.icesi.fi.tics.tssc.repositories;

import org.springframework.data.repository.CrudRepository;
import co.edu.icesi.fi.tics.tssc.model.TsscTopic;

public interface ITsscTopicRepository extends CrudRepository<TsscTopic, Long>{
	

//	public Iterable<TsscTopic> findByIdGame(@Param("idGame") long idGame);


}
