package co.edu.icesi.fi.tics.tssc.exceptions;

public class TopicNotExistException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TopicNotExistException() {
		super("The topic must exist");
	}
}
