package co.edu.icesi.fi.tics.tssc.exceptions;

public class AdminNotExistException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AdminNotExistException()
	{
		super("Admin must exist");
	}

}
