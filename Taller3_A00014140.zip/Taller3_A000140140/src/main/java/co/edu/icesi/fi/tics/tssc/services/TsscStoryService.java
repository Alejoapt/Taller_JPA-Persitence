package co.edu.icesi.fi.tics.tssc.services;

import java.math.BigDecimal;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.edu.icesi.fi.tics.tssc.exceptions.MinBusinessValueException;
import co.edu.icesi.fi.tics.tssc.exceptions.InitialSprintException;
import co.edu.icesi.fi.tics.tssc.exceptions.GameNotExistException;
import co.edu.icesi.fi.tics.tssc.exceptions.StoryNotExistException;
import co.edu.icesi.fi.tics.tssc.exceptions.GameNotNullException;
import co.edu.icesi.fi.tics.tssc.exceptions.StoryNotNullException;
import co.edu.icesi.fi.tics.tssc.exceptions.MinPriorityException;
import co.edu.icesi.fi.tics.tssc.model.TsscGame;
import co.edu.icesi.fi.tics.tssc.model.TsscStory;
import co.edu.icesi.fi.tics.tssc.repositories.ITsscGameRepository;
import co.edu.icesi.fi.tics.tssc.repositories.ITsscStoryRepository;

@Service
public class TsscStoryService implements ITsscStoryService{
	
	@Autowired
	private ITsscStoryRepository storyRepository;
	@Autowired
	private ITsscGameRepository gameRepository;

	@Override
	public TsscStory addStory(TsscStory story, TsscGame game) throws StoryNotNullException, MinBusinessValueException, InitialSprintException, MinPriorityException, GameNotNullException, GameNotExistException {
		
		if(story != null)
		{
			if((story.getBusinessValue().compareTo(BigDecimal.ZERO)!=0))
			 {
				if((story.getInitialSprint().compareTo(BigDecimal.ZERO)!=0))
				 {
					if((story.getPriority().compareTo(BigDecimal.ZERO)!=0))
					 {
						if(game != null)
						{
							if(gameRepository.existsById(game.getId()))
							{
								story.setTsscGame(game);
								story.setIdGame(game.getId());
								storyRepository.save(story);
								return story;
							}else throw new GameNotExistException();
						
						}else throw new GameNotNullException();
						
					}else throw new MinPriorityException();

				}else throw new InitialSprintException();

			}else throw new MinBusinessValueException();
		}else throw new StoryNotNullException();
	}

	@Override
	public TsscStory editStory(TsscStory story) throws StoryNotNullException, StoryNotExistException,MinBusinessValueException, MinPriorityException, InitialSprintException, GameNotExistException {
		if(story != null)
		{
			if(storyRepository.existsById(story.getId()))
			{
				if((story.getBusinessValue().compareTo(BigDecimal.ZERO)!=0))
				{
					if((story.getInitialSprint().compareTo(BigDecimal.ZERO)!=0))
					{
						if((story.getPriority().compareTo(BigDecimal.ZERO)!=0))
						{
								if(gameRepository.existsById(story.getTsscGame().getId()))
								{
									story.setTsscGame(story.getTsscGame());
									story.setIdGame(story.getTsscGame().getId());
									storyRepository.save(story);
									
									return story;
								}else throw new GameNotExistException();
							
						}else throw new MinPriorityException();
					}else throw new InitialSprintException();

				}else throw new MinBusinessValueException();
					
			}else throw new StoryNotExistException();

		}else throw new StoryNotNullException();
		
	}
	
	@Override
	public Iterable<TsscStory> findAll()
	{
		return storyRepository.findAll();
	}
	
	@Override
	public Optional<TsscStory> findStoryById(long id) {

		return storyRepository.findById(id);
	}

	@Override
	public void deleteStory(TsscStory story)
	{
		storyRepository.delete(story);
	}
	
	@Override
	public Iterable<TsscStory> findByGame(long id){
		return storyRepository.findByIdGame(id);
	}
	
}
