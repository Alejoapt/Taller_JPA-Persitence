package co.edu.icesi.fi.tics.tssc.dao;

import java.util.List;

import co.edu.icesi.fi.tics.tssc.model.TsscTopic;;

public interface ITsscTopicDao {

	// PN°1 a

	public List<TsscTopic> findTopicByName(String name);

	public List<TsscTopic> findTopicByDescription(String description);

	// -------------------------------------------------------------------------------------------

	public void add(TsscTopic entity);

	public void update(TsscTopic entity);

	public void delete(TsscTopic entity);

	public TsscTopic findTopicById(long id);

	public List<TsscTopic> findAll();

}
