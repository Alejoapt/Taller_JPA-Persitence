package co.edu.icesi.fi.tics.tssc.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.edu.icesi.fi.tics.tssc.exceptions.GroupNumberException;
import co.edu.icesi.fi.tics.tssc.exceptions.SprintNumberException;
import co.edu.icesi.fi.tics.tssc.exceptions.TopicNotExistException;
import co.edu.icesi.fi.tics.tssc.exceptions.TopicNotNullException;
import co.edu.icesi.fi.tics.tssc.model.TsscTopic;
import co.edu.icesi.fi.tics.tssc.repositories.ITsscTopicRepository;

@Service
public class TsscTopicService implements ITsscTopicService{
	
	@Autowired
	private ITsscTopicRepository topicRepository;

	@Override
	public TsscTopic saveTopic(TsscTopic topic) throws TopicNotNullException, GroupNumberException, SprintNumberException{
		if(topic != null)
		{
			if(topic.getDefaultGroups()>0)
			{
				if(topic.getDefaultSprints()>0)
				{
					topicRepository.save(topic);
					return topic;
				}else throw new SprintNumberException();
			}else throw new GroupNumberException();
				
		}else throw new TopicNotNullException();
			
	}

	@Override
	public TsscTopic editTopic(TsscTopic topic) throws TopicNotNullException, TopicNotExistException, SprintNumberException, GroupNumberException{
		if(topic != null)
		{
			if(topicRepository.existsById(topic.getId()))
			{
				if(topic.getDefaultGroups()>0)
				{
					if(topic.getDefaultSprints()>0)
					{
						topicRepository.save(topic);
						
					}else throw new SprintNumberException();
				}else throw new GroupNumberException();
				
				return topic;
			}else throw new TopicNotExistException();
		}else throw new TopicNotNullException();
	}
	
	@Override
	public Iterable<TsscTopic> findAll(){

		return topicRepository.findAll();
	}

	@Override
	public Optional<TsscTopic> findTopicById(long id) {

		return topicRepository.findById(id);
	}
	
	@Override 
	public void deleteTopic(TsscTopic topic)
	{
		topicRepository.delete(topic);
	}
	
//	@Override
//	public Iterable<TsscTopic> findByGame(long id){
//		return topicRepository.findByIdGame(id);
//	}

}
