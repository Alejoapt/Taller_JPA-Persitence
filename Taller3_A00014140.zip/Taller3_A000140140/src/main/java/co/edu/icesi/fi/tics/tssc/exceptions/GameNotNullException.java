package co.edu.icesi.fi.tics.tssc.exceptions;

public class GameNotNullException extends Exception {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GameNotNullException()
	{
		super("The story must be different than null");
	}
	
}

