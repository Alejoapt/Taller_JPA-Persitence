package co.edu.icesi.fi.tics.tssc.services;

import java.util.Optional;

import co.edu.icesi.fi.tics.tssc.exceptions.GroupNumberException;
import co.edu.icesi.fi.tics.tssc.exceptions.SprintNumberException;
import co.edu.icesi.fi.tics.tssc.exceptions.TopicNotExistException;
import co.edu.icesi.fi.tics.tssc.exceptions.TopicNotNullException;
import co.edu.icesi.fi.tics.tssc.model.TsscTopic;

public interface ITsscTopicService {
	
	public TsscTopic saveTopic(TsscTopic topic) throws TopicNotNullException, GroupNumberException, SprintNumberException;
	public TsscTopic editTopic(TsscTopic topic) throws TopicNotNullException, TopicNotExistException, SprintNumberException, GroupNumberException;
	public Iterable<TsscTopic> findAll();
	public Optional<TsscTopic> findTopicById(long id); 
//	public Iterable<TsscTopic> findByGame(long id);
	public void deleteTopic(TsscTopic topic);

}
