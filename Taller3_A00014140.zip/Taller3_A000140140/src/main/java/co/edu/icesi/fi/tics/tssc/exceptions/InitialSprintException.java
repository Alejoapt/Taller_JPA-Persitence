package co.edu.icesi.fi.tics.tssc.exceptions;

public class InitialSprintException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InitialSprintException() {
		super("The initial sprint must be different than 0");
	}
}
