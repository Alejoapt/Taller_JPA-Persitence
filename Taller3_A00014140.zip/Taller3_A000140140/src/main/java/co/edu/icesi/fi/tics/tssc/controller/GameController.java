package co.edu.icesi.fi.tics.tssc.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import co.edu.icesi.fi.tics.tssc.exceptions.GroupNumberException;
import co.edu.icesi.fi.tics.tssc.exceptions.SprintNumberException;
import co.edu.icesi.fi.tics.tssc.exceptions.GameNotExistException;
import co.edu.icesi.fi.tics.tssc.exceptions.TopicNotExistException;
import co.edu.icesi.fi.tics.tssc.exceptions.GameNotNullException;
import co.edu.icesi.fi.tics.tssc.model.ITsscGameValidation;
import co.edu.icesi.fi.tics.tssc.model.TsscGame;
import co.edu.icesi.fi.tics.tssc.model.TsscTopic;
import co.edu.icesi.fi.tics.tssc.services.TsscGameService;
import co.edu.icesi.fi.tics.tssc.services.TsscTopicService;

@Controller
public class GameController {

	private TsscGameService gameService;
	private TsscTopicService topicService;

	@Autowired
	public GameController(TsscGameService gameService, TsscTopicService topicService) {
		this.gameService = gameService;
		this.topicService = topicService;
	}

	/*
	 * Index for tsscGame
	 */
	@GetMapping("/tsscGames/")
	public String indexTsscGame(Model model) {
		model.addAttribute("games", gameService.findAll());
		model.addAttribute("topics", topicService.findAll());
		return "tsscGames/index";
	}

	/*
	 * Add mapping for tsscGames
	 */
	@GetMapping("tsscGames/add")
	public String addTsscGame(Model model) {
		model.addAttribute("game", new TsscGame());
		TsscTopic mock = new TsscTopic();
		mock.setName("No related topic");
		model.addAttribute("topics", topicService.findAll());
		model.addAttribute("mock", mock);
		return "tsscGames/addTsscGame";
	}

	/*
	 * Post mapping for add tsscGame
	 */
	@PostMapping("tsscGames/add")
	public String addTsscGame(@RequestParam(value = "action", required = true) String action,
			@Validated(ITsscGameValidation.class) @ModelAttribute("game") TsscGame game, BindingResult bindingResult,
			Model model) throws GameNotNullException, SprintNumberException, GameNotNullException, GroupNumberException,
			TopicNotExistException {
		if (!action.equals("Cancel")) {
			if (bindingResult.hasErrors()) {
				TsscTopic mock = new TsscTopic();
				mock.setName("No related topic");
				model.addAttribute("topics", topicService.findAll());
				model.addAttribute("mock", mock);
				return "games/addTsscGame";
			} else {
				gameService.addGame(game, game.getTsscTopic());
			}
		} else {
			return "tsscGames/index";
		}
		return "redirect:/tsscGames/";
	}

	/*
	 * Delete tsscGame
	 */
	@GetMapping("/tsscGames/del/{id}")
	public String deleteTsscGame(@PathVariable("id") long id) {
		TsscGame game = gameService.findGameById(id)
				.orElseThrow(() -> new IllegalArgumentException("Invalid Game Id: " + id));
		gameService.deleteGame(game);
		return "redirect:/tsscGames/";
	}

	/*
	 * Edit tsscGames mapping
	 */
	@GetMapping("/tsscGames/edit/{id}")
	public String editTsscGame(@PathVariable("id") long id, Model model) {
		Optional<TsscGame> tsscGame = gameService.findGameById(id);
		if (tsscGame == null)
			throw new IllegalArgumentException("Invalid Game Id: " + id);
		model.addAttribute("game", tsscGame.get());
		model.addAttribute("topics", topicService.findAll());
		return "tsscGames/editTsscGame";
	}

	/*
	 * Post mapping for tsscGame
	 */
	@PostMapping("/tsscGames/edit/{id}")
	public String editTsscGame(@PathVariable("id") long id,
			@RequestParam(value = "action", required = true) String action,
			@Validated(ITsscGameValidation.class) @ModelAttribute("game") TsscGame game, BindingResult bindingResult,
			Model model) throws TopicNotExistException, GameNotExistException, SprintNumberException,
			GameNotNullException, GroupNumberException {
		if (action != null && !action.equals("Cancel")) {
			if (bindingResult.hasErrors()) {
				return "/tsscGames/editTsscGame";
			} else {
				gameService.editGame(game);
			}
		}
		return "redirect:/tsscGames/";
	}

	/*
	 * Get tsscGames
	 */
	@GetMapping("/tsscGames/getGames/{id}")
	public String getGamesByTopic(@PathVariable long id, Model model) {
		model.addAttribute("games", gameService.findByIdTopic(id));
		return "tsscGames/indexGamesTopic";
	}

}
