package co.edu.icesi.fi.tics.tssc.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import co.edu.icesi.fi.tics.tssc.exceptions.MinBusinessValueException;
import co.edu.icesi.fi.tics.tssc.exceptions.InitialSprintException;
import co.edu.icesi.fi.tics.tssc.exceptions.GameNotExistException;
import co.edu.icesi.fi.tics.tssc.exceptions.StoryNotExistException;
import co.edu.icesi.fi.tics.tssc.exceptions.GameNotNullException;
import co.edu.icesi.fi.tics.tssc.exceptions.StoryNotNullException;
import co.edu.icesi.fi.tics.tssc.exceptions.MinPriorityException;
import co.edu.icesi.fi.tics.tssc.model.ITsscStoryValidation;
import co.edu.icesi.fi.tics.tssc.model.TsscStory;
import co.edu.icesi.fi.tics.tssc.services.TsscGameService;
import co.edu.icesi.fi.tics.tssc.services.TsscStoryService;

@Controller
public class StoryController {

	private TsscStoryService storyService;
	private TsscGameService gameService;

	@Autowired
	public StoryController(TsscStoryService storyService, TsscGameService gameService) {
		this.storyService = storyService;
		this.gameService = gameService;
	}

	/*
	 * Index for tsscStory
	 */
	@GetMapping("/tsscStories/")
	public String indexTsscStory(Model model) {
		model.addAttribute("stories", storyService.findAll());
		model.addAttribute("games", gameService.findAll());

		return "tsscStories/index";
	}

	/*
	 * Add tsscStory
	 */
	@GetMapping("tsscStories/add")
	public String addTsscStory(Model model) {
		model.addAttribute("story", new TsscStory());
		model.addAttribute("games", gameService.findAll());
		return "tsscStories/addTsscStory";
	}

	/*
	 * Add postmapping for tsscStory
	 */
	@PostMapping("tsscStories/add")
	public String addTsscStory(@RequestParam(value = "action", required = true) String action,
			@Validated(ITsscStoryValidation.class) @ModelAttribute("story") TsscStory story, BindingResult bindingResult,
			Model model) throws GameNotNullException, InitialSprintException, StoryNotNullException,
			MinBusinessValueException, MinPriorityException, GameNotExistException {
		if (!action.equals("Cancel")) {
			if (bindingResult.hasErrors()) {
				model.addAttribute("games", gameService.findAll());
				return "tsscStories/addTsscStory";
			} else {
				storyService.addStory(story, story.getTsscGame());
			}
		} else {
			return "tsscStories/index";
		}
		return "redirect:/tsscStories/";
	}

	/*
	 * Delete tsscStory
	 */
	@GetMapping("/tsscStories/del/{id}")
	public String deleteTsscStory(@PathVariable("id") long id) {
		TsscStory story = storyService.findStoryById(id)
				.orElseThrow(() -> new IllegalArgumentException("Invalidad Story Id: " + id));
		storyService.deleteStory(story);
		return "redirect:/tsscStories/";
	}

	/**
	 * Edit mapping for tsscStory
	 * 
	 * @param id
	 * @param model
	 * @return
	 */
	@GetMapping("/tsscStories/edit/{id}")
	public String editTsscStory(@PathVariable("id") long id, Model model) {
		Optional<TsscStory> story = storyService.findStoryById(id);
		if (story == null)
			throw new IllegalArgumentException("Invalid Story Id: " + id);
		model.addAttribute("story", story.get());
		model.addAttribute("games", gameService.findAll());
		return "tsscStories/editTsscStory";
	}

	/*
	 * Edit postmapping for tsscStory
	 */
	@PostMapping("/tsscStories/edit/{id}")
	public String editStory(@PathVariable("id") long id, @RequestParam(value = "action", required = true) String action,
			@Validated(ITsscStoryValidation.class) @ModelAttribute("story") TsscStory story, BindingResult bindingResult,
			Model model) throws MinPriorityException, StoryNotNullException, InitialSprintException,
			StoryNotExistException, MinBusinessValueException, GameNotExistException {
		if (action != null && !action.equals("Cancel")) {
			if (bindingResult.hasErrors()) {
				return "/tsscStories/editTsscStory";
			} else {
				storyService.editStory(story);
			}
		}
		return "redirect:/tsscStories/";
	}

	/*
	 * Get stories for games
	 */
	@GetMapping("/tsscStories/getStories/{id}")
	public String getTsscStories(@PathVariable("id") long id, Model model) {
		model.addAttribute("stories", storyService.findByGame(id));
		return "tsscStories/indexStoriesGame";
	}
}
