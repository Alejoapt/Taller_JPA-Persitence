package co.edu.icesi.fi.tics.tssc.exceptions;

public class AdminNotNullException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AdminNotNullException() {
		super("Admin must be different than null");
	}

}
