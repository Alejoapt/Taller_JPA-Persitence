package co.edu.icesi.fi.tics.tssc.services;

import java.util.Optional;

import co.edu.icesi.fi.tics.tssc.exceptions.MinBusinessValueException;
import co.edu.icesi.fi.tics.tssc.exceptions.InitialSprintException;
import co.edu.icesi.fi.tics.tssc.exceptions.GameNotExistException;
import co.edu.icesi.fi.tics.tssc.exceptions.StoryNotExistException;
import co.edu.icesi.fi.tics.tssc.exceptions.GameNotNullException;
import co.edu.icesi.fi.tics.tssc.exceptions.StoryNotNullException;
import co.edu.icesi.fi.tics.tssc.exceptions.MinPriorityException;
import co.edu.icesi.fi.tics.tssc.model.TsscGame;
import co.edu.icesi.fi.tics.tssc.model.TsscStory;

public interface ITsscStoryService {

	public TsscStory addStory(TsscStory story, TsscGame game) throws StoryNotNullException, MinBusinessValueException, InitialSprintException, MinPriorityException, GameNotNullException, GameNotExistException;
	public TsscStory editStory(TsscStory story) throws StoryNotNullException, StoryNotExistException, MinPriorityException, MinBusinessValueException, InitialSprintException, GameNotExistException;
	public void deleteStory(TsscStory story);
	public Iterable<TsscStory> findAll();
	public Optional<TsscStory> findStoryById(long id);
	public Iterable<TsscStory> findByGame(long id);
}
