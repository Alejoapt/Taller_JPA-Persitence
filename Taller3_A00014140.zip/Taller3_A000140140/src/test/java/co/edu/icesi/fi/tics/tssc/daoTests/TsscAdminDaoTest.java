package co.edu.icesi.fi.tics.tssc.daoTests;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import co.edu.icesi.fi.tics.tssc.Taller2Application;
import co.edu.icesi.fi.tics.tssc.dao.TsscAdminDao;
import co.edu.icesi.fi.tics.tssc.model.TsscAdmin;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = Taller2Application.class)
@Rollback(false)
public class TsscAdminDaoTest {

	@Autowired
	private TsscAdminDao tsscAdminDao;
	private TsscAdmin aAdmin;
	private TsscAdmin bAdmin;

	public void setUp() {
		aAdmin = new TsscAdmin();
		aAdmin.setUser("Admin a");
		bAdmin = new TsscAdmin();
		bAdmin.setUser("Admin b");
	}

	@Test
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@DisplayName("Add Admin")
	public void test1() {
		setUp();
		assertEquals(0, tsscAdminDao.findAll().size());
		tsscAdminDao.add(aAdmin);
		tsscAdminDao.add(bAdmin);
		assertEquals(2, tsscAdminDao.findAll().size());
	}

	@Test
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@DisplayName("Update Admin")
	public void test2() {
		TsscAdmin t = tsscAdminDao.findAdminById(2);
		String user = "User";
		t.setUser(user);
		tsscAdminDao.update(t);
		assertEquals(user, tsscAdminDao.findAdminById(2).getUser());
	}


	@Test
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@DisplayName("Find by id")
	public void test4() {
		List<TsscAdmin> adminList = tsscAdminDao.findAll();
		assertEquals(adminList.get(0), tsscAdminDao.findAdminById(1));
	}
	
	@Test
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@DisplayName("Delete Admin")
	public void test5() {
		assertEquals(2, tsscAdminDao.findAll().size());
		tsscAdminDao.delete(tsscAdminDao.findAll().get(0));
		assertEquals(1, tsscAdminDao.findAll().size());
	}


}
