package co.edu.icesi.fi.tics.tssc.daoTests;


import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import co.edu.icesi.fi.tics.tssc.Taller2Application;
import co.edu.icesi.fi.tics.tssc.dao.TsscTopicDao;
import co.edu.icesi.fi.tics.tssc.model.TsscTopic;


@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = Taller2Application.class)
@Rollback(false)
@TestMethodOrder(OrderAnnotation.class)
public class TsscTopicDaoTest {
	
	@Autowired
	private TsscTopicDao topicDao;
	private TsscTopic topicTest1;
	private TsscTopic topicTest2;
	
	
	public void setUp()
	{
		topicTest1 = new TsscTopic();
		topicTest1.setName("Topic a");
		topicTest1.setDescription("Description Topic a");	
		topicTest2 = new TsscTopic();
		topicTest2.setName("Topic b");
		topicTest2.setDescription("Description Topic b");
	}
	
	@Test
	@Order(1)
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@DisplayName("Add topic")
	public void addTest()
	{
		setUp();
		assertEquals(0,topicDao.findAll().size());
		topicDao.add(topicTest1);
		topicDao.add(topicTest2);
		assertEquals(2,topicDao.findAll().size());
	}
	@Test
	@Order(2)
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@DisplayName("Update topic")
	public void updateTest()
	{
		TsscTopic t = topicDao.findTopicById(2);
		String name = "Topic a";
		t.setName(name);
		topicDao.update(t);
		assertEquals(name, topicDao.findTopicById(2).getName());
	}
	
	@Test
	@Order(2)
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@DisplayName("Find topic by id")
	public void findTopicByIdTest()
	{
		List<TsscTopic> topics = topicDao.findAll();
		assertEquals(topics.get(0), topicDao.findTopicById(1));
	}
	
	@Test
	@Order(2)
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@DisplayName("Find topic by name")
	public void findTopicByNameTest()
	{
		assertEquals("Topic a", topicDao.findTopicByName("Topic a").get(0).getName());
	}
	@Test
	@Order(2)
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@DisplayName("Find by description")
	public void findTopicByDescriptionTest()
	{
		String description = "Description Topic b";
		assertEquals(description, topicDao.findTopicByDescription(description).get(0).getDescription());
	}
	
	
	@Test
	@Order(3)
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@DisplayName("Delete topic")
	public void deleteTopicTest()
	{
		assertEquals(2,topicDao.findAll().size());
		List<TsscTopic> topics = topicDao.findAll();
		topicDao.delete(topics.get(0));
		assertEquals(1,topicDao.findAll().size());
	}
	
	
}

