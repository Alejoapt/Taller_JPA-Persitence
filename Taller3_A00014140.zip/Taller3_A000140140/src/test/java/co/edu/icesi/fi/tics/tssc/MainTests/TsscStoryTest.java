package co.edu.icesi.fi.tics.tssc.MainTests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import co.edu.icesi.fi.tics.tssc.exceptions.*;

import co.edu.icesi.fi.tics.tssc.model.TsscGame;
import co.edu.icesi.fi.tics.tssc.model.TsscStory;
import co.edu.icesi.fi.tics.tssc.repositories.ITsscGameRepository;
import co.edu.icesi.fi.tics.tssc.repositories.ITsscStoryRepository;
import co.edu.icesi.fi.tics.tssc.services.TsscGameService;
import co.edu.icesi.fi.tics.tssc.services.TsscStoryService;
import co.edu.icesi.fi.tics.tssc.services.TsscTopicService;

public class TsscStoryTest {

	@Mock
	private ITsscGameRepository tsscGameRepo;

	@Mock
	private ITsscStoryRepository tsscStoryRepo;

	@InjectMocks
	private TsscGameService tsscGameService;

	@InjectMocks
	private TsscTopicService tsscTopicService;

	@InjectMocks
	private TsscStoryService tsscStoryService;

	private TsscGame tsscGame;

	private TsscStory tsscStory;

	@BeforeEach
	public void init() {

		MockitoAnnotations.initMocks(this);
		tsscStory = new TsscStory();
		tsscStory.setBusinessValue(new BigDecimal("100"));
		tsscStory.setPriority(new BigDecimal("100"));
		tsscStory.setInitialSprint(new BigDecimal("5"));

		tsscGame = new TsscGame();
		tsscGame.setId(12);

		tsscStory.setTsscGame(tsscGame);

	}

	@Test
	@DisplayName("Not enough priority test ")
	public void addPriorityTest() {
		tsscStory.setPriority(new BigDecimal("0"));
		assertThrows(MinPriorityException.class, () -> tsscStoryService.addStory(tsscStory, null));
	}
	
	@Test
	@DisplayName("Null game")
	public void addNullTest() {
		assertThrows(StoryNotNullException.class, () -> tsscStoryService.addStory(null, null));
	}

	@Test
	@DisplayName("Not enough business value test")
	public void addBusinessValueTest() {
		tsscStory.setBusinessValue(new BigDecimal("0"));
		assertThrows(MinBusinessValueException.class, () -> tsscStoryService.addStory(tsscStory, null));
	}

	@Test
	@DisplayName("Not enough value for initial sprint test")
	public void addInitialSprintTest() {
		tsscStory.setInitialSprint(new BigDecimal("0"));
		assertThrows(InitialSprintException.class, () -> tsscStoryService.addStory(tsscStory, null));
	}


	@Test
	@DisplayName("Successful addition")
	public void addTest() {
		when(tsscGameRepo.existsById(tsscGame.getId())).thenReturn(true);
		try {
			assertEquals(tsscStory, tsscStoryService.addStory(tsscStory, tsscGame));
			verify(tsscStoryRepo, times(1)).save(tsscStory);

		} catch (StoryNotNullException | MinBusinessValueException | InitialSprintException | MinPriorityException
				| GameNotNullException | GameNotExistException e) {
		}

	}

	@Test
	@DisplayName("Null story for editting")
	public void editNullTest() {
		assertThrows(StoryNotNullException.class, () -> tsscStoryService.editStory(null));
	}

	@Test
	@DisplayName("Not existing story for editting")
	public void editStoryTest() {
		when(tsscStoryRepo.existsById(tsscStory.getId())).thenReturn(false);
		assertThrows(StoryNotExistException.class, () -> tsscStoryService.editStory(tsscStory));
		verify(tsscStoryRepo, times(0)).save(tsscStory);

	}



}
