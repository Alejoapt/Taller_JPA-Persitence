package co.edu.icesi.fi.tics.tssc.daoTests;

import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import co.edu.icesi.fi.tics.tssc.Taller2Application;
import co.edu.icesi.fi.tics.tssc.dao.TsscGameDao;
import co.edu.icesi.fi.tics.tssc.dao.TsscTopicDao;
import co.edu.icesi.fi.tics.tssc.model.TsscGame;
import co.edu.icesi.fi.tics.tssc.model.TsscTopic;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = Taller2Application.class)
@Rollback(false)
@TestMethodOrder(OrderAnnotation.class)
public class TsscGameDaoTest {

	@Autowired
	private TsscGameDao tsscGameDao;

	@Autowired
	private TsscTopicDao tsscTopicDao;

	private TsscGame gameA, gameB;
	private TsscTopic topicA, topicB;

	@Test
	@Order(1)
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@DisplayName("Add game")
	public void addTest() {
		setUp();
		tsscTopicDao.add(topicA);
		tsscTopicDao.add(topicB);
		assertEquals(0, tsscGameDao.findAll().size());
		tsscGameDao.add(gameA);
		tsscGameDao.add(gameB);
		assertEquals(2, tsscGameDao.findAll().size());

	}

	@Test
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@Order(2)
	@DisplayName("Update game")
	public void updateTest() {
		TsscGame g = tsscGameDao.findGameById(1);
		String name = "Game a";
		g.setName(name);
		tsscGameDao.update(g);
		assertEquals(name, tsscGameDao.findGameById(1).getName());

	}

	@Test
	@Order(2)
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@DisplayName("Find Game by id")
	public void findGameByIdTest() {
		List<TsscGame> games = tsscGameDao.findAll();
		assertEquals(games.get(0), tsscGameDao.findGameById(1));
	}

	@Test

	@Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@DisplayName("Find Game by name")
	public void findGameByNameTest() {
		String name = "Game 2";
		assertEquals(name, tsscGameDao.findByName(name).get(0).getName());
	}

	@Test
	@Order(2)
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@DisplayName("Find by description")
	public void findGameByDescriptionTest() {
		String description = "Description Game A";
		assertEquals(description, tsscGameDao.findByDescription(description).get(0).getDescription());
	}

	@Test
	@Order(4)
	@Transactional(readOnly = false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@DisplayName("Delete game")
	public void deleteGameTest() {
		assertEquals(2, tsscGameDao.findAll().size());
		tsscGameDao.delete(tsscGameDao.findGameById(1));
		assertEquals(1, tsscGameDao.findAll().size());

	}

	public void setUp() {
		gameA = new TsscGame();
		gameB = new TsscGame();
		topicA = new TsscTopic();
		topicA.setName("Topic 1");
		topicB = new TsscTopic();
		topicB.setName("Topic 2");
		gameA.setDescription("Description Game A");
		gameA.setTsscTopic(topicA);
		gameA.setName("Game 1");
		gameB.setTsscTopic(topicA);
		gameB.setName("Game 2");
		gameB.setDescription("Description Game B");

	}


}
