package co.edu.icesi.fi.tics.tssc.MainTests;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import co.edu.icesi.fi.tics.tssc.exceptions.*;
import co.edu.icesi.fi.tics.tssc.model.TsscTopic;
import co.edu.icesi.fi.tics.tssc.repositories.ITsscTopicRepository;

import co.edu.icesi.fi.tics.tssc.services.TsscTopicService;

public class TsscTopicTest {

	@Mock
	private ITsscTopicRepository mock;

	@InjectMocks
	private TsscTopicService topicService;
	private TsscTopic topic;

	@BeforeEach
	public void setup() {
		MockitoAnnotations.initMocks(this);
		topic = new TsscTopic();
		topic.setId(0123);
//		topic.setName("Topic 1");
		topic.setGroupPrefix("t1");

	}

	@Test
	@DisplayName("Not enough sprints")
	public void addSprintTest() {
		topic.setDefaultGroups(4);
		assertThrows(SprintNumberException.class, () -> topicService.saveTopic(topic));
	}

	@Test
	@DisplayName("Not enough groups test")
	public void addGroupTest() {
		topic.setDefaultSprints(4);
		assertThrows(GroupNumberException.class, () -> topicService.saveTopic(topic));
	}

	@Test
	@DisplayName("Null topic test")
	public void addNullTest() {
		assertThrows(TopicNotNullException.class, () -> topicService.saveTopic(null));

	}

	@Test
	@DisplayName("Successful add")
	public void addTest() {
		topic.setDefaultGroups(4);
		topic.setDefaultSprints(4);
		when(mock.save(topic)).thenReturn(topic);
		try {
			assertEquals(topic, topicService.saveTopic(topic));
		} catch (TopicNotNullException | GroupNumberException | SprintNumberException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		verify(mock, times(1)).save(topic);
	}


	@Test
	@DisplayName("Null topic for editting test")
	public void editNullTest() {
		assertThrows(TopicNotNullException.class, () -> topicService.editTopic(null));
	}


}
