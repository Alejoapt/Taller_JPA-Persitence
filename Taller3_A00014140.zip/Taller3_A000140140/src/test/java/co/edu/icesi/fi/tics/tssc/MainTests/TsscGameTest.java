package co.edu.icesi.fi.tics.tssc.MainTests;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import co.edu.icesi.fi.tics.tssc.exceptions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import co.edu.icesi.fi.tics.tssc.model.TsscGame;
import co.edu.icesi.fi.tics.tssc.model.TsscTopic;
import co.edu.icesi.fi.tics.tssc.repositories.ITsscGameRepository;
import co.edu.icesi.fi.tics.tssc.repositories.ITsscTopicRepository;

import co.edu.icesi.fi.tics.tssc.services.TsscGameService;
import co.edu.icesi.fi.tics.tssc.services.TsscTopicService;

public class TsscGameTest {

	@Mock
	private ITsscGameRepository tsscGameRepo;

	@Mock
	private ITsscTopicRepository tsscTopicRepo;

	@InjectMocks
	private TsscGameService tsscGameService;

	@InjectMocks
	private TsscTopicService topicService;

	private TsscGame tsscGame;
	private TsscTopic tsscTopic;

	@BeforeEach
	public void setup() {
		MockitoAnnotations.initMocks(this);
		tsscGame = new TsscGame();
		tsscGame.setId(123);
		tsscGame.setNGroups(2);
		tsscGame.setNSprints(2);

		tsscTopic = new TsscTopic();
		tsscTopic.setId(123);

	}


	@Test
	@DisplayName("Not enough groups test")
	public void addGroupTest() {
		tsscGame.setNGroups(0);
		assertThrows(GroupNumberException.class, () -> tsscGameService.addGame(tsscGame, null));
	}

	@Test
	@DisplayName("Not enough sprints test")
	public void addSprintTest() {
		tsscGame.setNSprints(0);
		assertThrows(SprintNumberException.class, () -> tsscGameService.addGame(tsscGame, null));
	}

	
	@Test
	@DisplayName("Null game")
	public void addNullTest() {
		assertThrows(GameNotNullException.class, () -> tsscGameService.addGame(null, null));
	}

	@Test
	@DisplayName("An unexisting topic is added")
	public void addExistTopicTest() {
		when(tsscTopicRepo.existsById((long) 123.0)).thenReturn(false);

		assertThrows(TopicNotExistException.class, () -> tsscGameService.addGame(tsscGame, tsscTopic));
	}



	@Test
	@DisplayName("Not enough groups test")
	public void editGroupTest() {
		tsscGame.setNGroups(0);
		when(tsscGameRepo.existsById(tsscGame.getId())).thenReturn(true);
		assertThrows(GroupNumberException.class, () -> tsscGameService.editGame(tsscGame));
		verify(tsscGameRepo, times(0)).save(tsscGame);

	}

	@Test
	@DisplayName("Not enough sprints test")
	public void editSprintTest() {
		tsscGame.setNSprints(0);
		when(tsscGameRepo.existsById(tsscGame.getId())).thenReturn(true);
		assertThrows(SprintNumberException.class, () -> tsscGameService.editGame(tsscGame));
		verify(tsscGameRepo, times(0)).save(tsscGame);
	}

	
	@Test
	@DisplayName("Null game edit test")
	public void editNullTest() {
		assertThrows(GameNotNullException.class, () -> tsscGameService.editGame(null));
	}

	
	@Test
	@DisplayName("An unexisting topic is edited")
	public void editTopicTest() {
		when(tsscGameRepo.existsById(tsscGame.getId())).thenReturn(true);
		when(tsscTopicRepo.existsById((long) 123.0)).thenReturn(false);
		tsscGame.setTsscTopic(tsscTopic);
		assertThrows(TopicNotExistException.class, () -> tsscGameService.editGame(tsscGame));
		verify(tsscGameRepo, times(0)).save(tsscGame);

	}



}
