package co.edu.icesi.fi.tics.tssc.daoTests;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import co.edu.icesi.fi.tics.tssc.Taller2Application;
import co.edu.icesi.fi.tics.tssc.dao.TsscGameDao;
import co.edu.icesi.fi.tics.tssc.dao.TsscStoryDao;
import co.edu.icesi.fi.tics.tssc.model.TsscGame;
import co.edu.icesi.fi.tics.tssc.model.TsscStory;


@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = Taller2Application.class)
@Rollback(false)
@TestMethodOrder(OrderAnnotation.class)
public class TsscStoryDaoTest {
	
	@Autowired
	private TsscStoryDao storyDao;
	
	@Autowired
	private TsscGameDao gameDao;
	
	private TsscStory tsscStorya;
	private TsscStory tsscStoryb;
	private TsscGame tsscGame;
	
	
	public void setUp()
	{
		tsscGame = new TsscGame();
		tsscGame.setName("Game");
		tsscStorya = new TsscStory();
		tsscStorya.setDescription("Story a");
		tsscStoryb = new TsscStory();
		tsscStoryb.setDescription("Story b");
		tsscStorya.setTsscGame(tsscGame);

	}
	
	@Test
	@Order(1)
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@DisplayName("Add Story")
	public void addTest()
	{
		setUp();
		gameDao.add(tsscGame);
		assertEquals(0,storyDao.findAll().size());
		storyDao.add(tsscStorya);
		storyDao.add(tsscStoryb);
		assertEquals(2,storyDao.findAll().size());
	}
	@Test
	@Order(2)
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@DisplayName("Update topic")
	public void updateTest()
	{
		TsscStory t = storyDao.findStoryById(2);
		String description = "Historia vieja";
		t.setDescription(description);
		storyDao.update(t);
		assertEquals(description, storyDao.findStoryById(2).getDescription());
	}
	
	@Test
	@Order(2)
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@DisplayName("Find by id")
	public void findStoryByIdTest()
	{
		List<TsscStory> stories = storyDao.findAll();
		assertEquals(stories.get(0), storyDao.findStoryById(1));
	}
	
	@Test
	@Order(2)
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@DisplayName("Find by game")
	public void findStoryByGameTest()
	{
		assertEquals("Historia test 1", storyDao.findStoryByGame(1).get(0).getDescription());
	}

	
	@Test
	@Order(3)
	@Transactional(readOnly=false, propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	@DisplayName("Delete Story")
	public void deleteStory()
	{
		assertEquals(2,storyDao.findAll().size());
		storyDao.delete(storyDao.findAll().get(0));
		assertEquals(1,storyDao.findAll().size());
	}
	
	



}
