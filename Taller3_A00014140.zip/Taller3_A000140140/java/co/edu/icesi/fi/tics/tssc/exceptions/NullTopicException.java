package co.edu.icesi.fi.tics.tssc.exceptions;

public class NullTopicException extends Exception {
	
	public NullTopicException()
	{
		super("Null Story");
	}
	
	

}
