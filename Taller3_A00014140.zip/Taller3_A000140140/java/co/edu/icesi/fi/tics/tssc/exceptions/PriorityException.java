package co.edu.icesi.fi.tics.tssc.exceptions;

public class PriorityException extends Exception{

	public PriorityException() {
		super("The business value has to be greater than 0NotEnoughGroupsException.java");
	}
}
