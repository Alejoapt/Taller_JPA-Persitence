package co.edu.icesi.fi.tics.tssc.exceptions;

public class NullAdminException extends Exception {
	
	public NullAdminException() {
		super("Null Admin");
	}

}
