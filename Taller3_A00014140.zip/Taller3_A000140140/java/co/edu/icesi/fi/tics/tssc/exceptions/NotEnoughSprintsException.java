package co.edu.icesi.fi.tics.tssc.exceptions;

public class NotEnoughSprintsException extends Exception{
	
	public NotEnoughSprintsException() {
		super("Not enought sprints");
	}
	

}
