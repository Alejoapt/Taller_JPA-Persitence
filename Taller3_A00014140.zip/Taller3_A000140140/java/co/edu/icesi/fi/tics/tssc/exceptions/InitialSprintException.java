package co.edu.icesi.fi.tics.tssc.exceptions;

public class InitialSprintException extends Exception{

	public InitialSprintException() {
		super("The priority of the story has to be greater than 0NotEnoughGroupsException.java");
	}
}
