package co.edu.icesi.fi.tics.tssc.exceptions;

public class NullStoryException extends Exception {
	
	public NullStoryException()
	{
		super("Null Topic");
	}
	
	

}
