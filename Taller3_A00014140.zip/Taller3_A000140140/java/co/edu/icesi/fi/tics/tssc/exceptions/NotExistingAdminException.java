package co.edu.icesi.fi.tics.tssc.exceptions;

public class NotExistingAdminException extends Exception {
	
	public NotExistingAdminException()
	{
		super("Not existing admin");
	}

}
