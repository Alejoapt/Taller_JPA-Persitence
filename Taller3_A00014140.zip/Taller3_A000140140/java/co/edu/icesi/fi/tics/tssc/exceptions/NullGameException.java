package co.edu.icesi.fi.tics.tssc.exceptions;

public class NullGameException extends Exception {


	public NullGameException()
	{
		super("Null Game");
	}
	
}

