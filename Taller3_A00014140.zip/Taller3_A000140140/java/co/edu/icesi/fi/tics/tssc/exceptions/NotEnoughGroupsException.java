package co.edu.icesi.fi.tics.tssc.exceptions;

public class NotEnoughGroupsException extends Exception{

	public NotEnoughGroupsException() {
		super("Not enough groups");
	}
}
