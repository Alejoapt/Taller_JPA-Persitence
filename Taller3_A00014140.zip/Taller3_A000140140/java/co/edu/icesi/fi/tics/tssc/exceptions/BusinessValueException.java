package co.edu.icesi.fi.tics.tssc.exceptions;

public class BusinessValueException extends Exception{

	public BusinessValueException() {
		super("The initial sprint of the story has to be greater than 0NotEnoughGroupsException.java");
	}
}
